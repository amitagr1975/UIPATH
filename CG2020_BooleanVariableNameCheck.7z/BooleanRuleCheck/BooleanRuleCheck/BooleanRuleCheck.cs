﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using UiPath.Activities;
using UiPath.Studio.Activities.Api;
using UiPath.Studio.Activities.Api.Analyzer;
using UiPath.Studio.Activities.Api.Analyzer.Rules;
using UiPath.Studio.Analyzer;
using UiPath.Studio.Analyzer.Models;

namespace ClassLibrary6
{
    public class RuleRepository : IRegisterAnalyzerConfiguration
    {
        public object VariableNamingRule { get; private set; }

        public void Initialize(IAnalyzerConfigurationService workflowAnalyzerConfigService)
        {
            if (!workflowAnalyzerConfigService.hasFeature("WorkflowAnalyzerV4"))
                return;
            workflowAnalyzerConfigService.AddRule<IActivityModel>();
        }

        internal static class BooleenVariableNamingRule
        {
            private const string RuleId = "ST-NMG-010";
            private const string RegexKey = "Regex";
            private const string DefaultRegex = @"^(is|has)|exist$";

            public static string Recommendation { get; private set; }

            internal static Rule<IActivityModel> Get()
            {
                var rule = new Rule<IActivityModel>(Strings.ST_NMG_010_Name, RuleId, Inspect)
                {
                    RecommendationMessage = Recommendation,
                    ErrorLevel = System.Diagnostics.TraceLevel.Warning
                };
                rule.Parameters.Add(RegexKey, new Parameter());
                return rule;
            }

            private static InspectionResult Inspect(IActivityModel activityModel, Rule ruleInstance)
            {
                // This retrieves the parameter value from the rule instance as configured by the user, if not, the default value.
                var setRegexValue = ruleInstance.Parameters[RegexKey]?.Value;

                var regex = new System.Text.RegularExpressions.Regex(setRegexValue);
                var messageList = new List<string>();
                foreach (var activityModelVariable in activityModel.Variables)
                {
                    if (!regex.IsMatch(activityModelVariable.DisplayName))
                    {
                        messageList.Add(string.Format(Strings.ST_NMG_010_Name, activityModelVariable.DisplayName, setRegexValue));
                    }
                }

                if (messageList.Count > 0)
                {
                    return new InspectionResult()
                    {
                        ErrorLevel = ruleInstance.ErrorLevel,
                        HasErrors = true,
                        RecommendationMessage = ruleInstance.RecommendationMessage,
                        Messages = messageList
                    };
                }
                else
                {
                    return new InspectionResult() { HasErrors = false };
                }
            }
        }


    }
}
